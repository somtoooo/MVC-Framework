<?php  $this->start('head'); ?>
<?php  $this->end(); ?>
<?php  $this->start('body'); ?>
<div class="row m-1">
  <div class="col-md-6">
    <div class="white m-2 p-4 rounded">
      <h3 class="text-center">Login</h3>
      <form class="form" action="<?=PROOT;?>register/login" method="post">
        <div class="form-group">
          <label for="username">Username</label>
          <input class="form-control" type="text" name="username" id="username" placeholder="example@example.com" value="">
        </div>
        <div class="form-group">
          <label for="password">Password</label>
          <input class="form-control" type="password" name="password" id="password" value="">
        </div>
        <div class="form-group">
          <label for="remember_me">Remember Me <input class="" type="checkbox" name="remember_me" id="remember_me" value="on"></label>
        </div>
        <!--<div class="form-group">
          <a href="#" class="">Forgotten Password?</a>
        </div>-->
        <div class="form-group">
          <input type="submit" class="btn btn-primary" value="Login">
        </div>
      </form>
    </div>
  </div>
  <div class="col-sm-6">
    <div class="white m-2 p-4 rounded">
    <h4 class="mt-3">New Customer</h4>
    <h6>Register</h6>
    <p>By creating an account you will be able to shop faster,
      be up to date on an order's status,
      and keep track of the orders you have previously made.
    </p>
    <a href="<?= PROOT; ?>register/register" class="btn btn-primary">Continue</a>
    </div>
  </div>
</div>
<?php  $this->end(); ?>
