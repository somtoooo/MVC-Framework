<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0">
    <title><?= $this->siteTitle(); ?></title>
    <link rel="stylesheet" href="<?= PROOT; ?>css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= PROOT; ?>css/custom.css">

    <?= $this->content('head'); ?>
  </head>
  <body>
    <?= $this->content('body'); ?>
    <script type="text/javascript" src="<?= PROOT; ?>js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript" src="<?= PROOT; ?>js/jquery-3.3.1.min.js"></script>
    <script type="text/javascript" src="<?= PROOT; ?>js/bootstrap.min.js"></script>
  </body>
</html>
