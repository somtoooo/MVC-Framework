<?php  $this->start('body'); ?>
<h1 class="text-center text-success">Welcome to MVC Framework</h1>
<?php  $this->end(); ?>
