<?php
  define('DEBUG', true);

  define('DB_NAME', 'MVC'); // databaase name
  define('DB_USER', 'root'); // database user
  define('DB_PASSWORD', ''); // database password
  define('DB_HOST', '127.0.0.1'); // database host *** use IP address to avoid DNS lookup

  define('DEFAULT_CONTROLLER', 'Home'); //default controller if there is none in the url
  define('DEFAULT_LAYOUT', 'default');//if no layout is set in the controller use this layout

  define('PROOT', '/MVCFramework/');// set this to '/' for a live.

  define('SITE_TITLE', 'MVC Framework');// this will be used if no site title is set

  define('CURRENT_USER_SESSION_NAME', 'gtAuyRoTqQYuaTQonHjQmvie');// session name for logged in user
  define('REMEMBER_ME_COOKIE_NAME', 'JY98fu5cE17Hry6oT76njW45Oq');// cookie name for logged in user remeber me
  define('REMEMBER_ME_COOKIE_EXPIRY', 2592000);// time in seconds for remember me cookie to live (30 days)
